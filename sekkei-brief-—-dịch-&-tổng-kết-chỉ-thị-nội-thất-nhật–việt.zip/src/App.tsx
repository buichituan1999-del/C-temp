import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, X } from 'lucide-react';
import {
  AnalyzedPage,
  BoundingBox2D,
  DirectiveItem,
  DirectiveStatus,
  DocumentProject,
  ExecutiveSummary,
} from './types';
import {
  cropDirectiveFromPage,
  generateSampleJapaneseInteriorPdf,
  renderPdfToPages,
} from './utils/pdfProcessor';
import { UploadWorkspace } from './components/UploadWorkspace';
import { SummaryView } from './components/SummaryView';
import { DirectivesView } from './components/DirectivesView';
import { DrawingInspectorView } from './components/DrawingInspectorView';
import { GlossaryView } from './components/GlossaryView';

type ActiveTab = 'upload' | 'summary' | 'directives' | 'inspector' | 'glossary';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('upload');
  const [project, setProject] = useState<DocumentProject | null>(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [progressText, setProgressText] = useState('');
  const [progressPercent, setProgressPercent] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastFile, setLastFile] = useState<File | null>(null);
  const [completionNotice, setCompletionNotice] = useState<{
    title: string;
    subtitle: string;
    allDone?: boolean;
    onUndo?: () => void;
  } | null>(null);
  const noticeTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (noticeTimerRef.current) window.clearTimeout(noticeTimerRef.current);
    };
  }, []);

  const showCompletionNotice = (notice: {
    title: string;
    subtitle: string;
    allDone?: boolean;
    onUndo?: () => void;
  }) => {
    setCompletionNotice(notice);
    if (noticeTimerRef.current) window.clearTimeout(noticeTimerRef.current);
    noticeTimerRef.current = window.setTimeout(() => {
      setCompletionNotice(null);
    }, 4500);
  };

  const [directivesCategoryFilter, setDirectivesCategoryFilter] = useState<string>('all');
  const [inspectorPageNumber, setInspectorPageNumber] = useState<number>(1);
  const [inspectorDirectiveId, setInspectorDirectiveId] = useState<string | undefined>(undefined);

  const processPdfFile = async (file: File) => {
    setLastFile(file);
    setIsProcessing(true);
    setErrorMessage(null);
    setProgressPercent(5);
    setProgressText(`Đang đọc cấu trúc file "${file.name}"...`);

    try {
      const renderedPages = await renderPdfToPages(file, (curr, total) => {
        setProgressText(`Đang kết xuất hình ảnh độ nét cao: Trang ${curr} / ${total}...`);
        setProgressPercent(5 + Math.round((curr / total) * 20));
      });

      if (renderedPages.length === 0) {
        throw new Error('File PDF không có trang nào để phân tích.');
      }

      const analyzedPages: AnalyzedPage[] = [];
      const total = renderedPages.length;
      let globalSeq = 0;

      for (let i = 0; i < total; i++) {
        const page = renderedPages[i];
        setProgressText(
          `Đang dịch tiếng Nhật & khoanh vùng chỉ thị: Trang ${page.pageNumber} / ${total}...`
        );
        setProgressPercent(25 + Math.round(((i + 0.3) / total) * 60));

        let res = await fetch('/api/analyze-page', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            pageNumber: page.pageNumber,
            imageDataUrl: page.imageDataUrl,
            extractedText: page.extractedText,
            fileName: file.name,
          }),
        });

        if (res.status === 503 || res.status === 429) {
          setProgressText(
            `Máy chủ AI đang bận, đang tự động thử lại trang ${page.pageNumber} / ${total}...`
          );
          await new Promise((resolve) => setTimeout(resolve, 2500));
          res = await fetch('/api/analyze-page', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              pageNumber: page.pageNumber,
              imageDataUrl: page.imageDataUrl,
              extractedText: page.extractedText,
              fileName: file.name,
            }),
          });
        }

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || `Lỗi khi phân tích trang ${page.pageNumber}.`);
        }

        setProgressText(`Đang chụp cắt hình ảnh vùng chỉ thị trên trang ${page.pageNumber}...`);
        const rawDirectives: DirectiveItem[] = Array.isArray(data.directives)
          ? data.directives
          : [];

        const croppedDirectives = await Promise.all(
          rawDirectives.map(async (d) => {
            const assignedSeq = ++globalSeq;
            const enriched = {
              ...d,
              pdfSequence: assignedSeq,
              pdfMark: d.pdfMark?.trim() || undefined,
            };
            try {
              const croppedUrl = await cropDirectiveFromPage(page.imageDataUrl, d.box_2d);
              return { ...enriched, croppedImageUrl: croppedUrl };
            } catch {
              return enriched;
            }
          })
        );

        analyzedPages.push({
          pageNumber: page.pageNumber,
          width: page.width,
          height: page.height,
          imageDataUrl: page.imageDataUrl,
          extractedText: page.extractedText,
          documentTypeVi: data.documentTypeVi,
          pageTitleVi: data.pageTitleVi,
          pageSummaryVi: data.pageSummaryVi,
          translationBlocks: data.translationBlocks ?? [],
          directives: croppedDirectives,
          glossaryTerms: data.glossaryTerms ?? [],
        });

        setProgressPercent(25 + Math.round(((i + 1) / total) * 60));
      }

      setProgressText('Đang tổng kết toàn bộ chỉ thị cần làm & chỉnh sửa...');
      setProgressPercent(90);

      let executiveSummary: ExecutiveSummary | null = null;
      try {
        const sumRes = await fetch('/api/synthesize-summary', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            pages: analyzedPages.map((p) => ({
              pageNumber: p.pageNumber,
              pageTitleVi: p.pageTitleVi,
              pageSummaryVi: p.pageSummaryVi,
              directives: p.directives.map((d) => ({
                category: d.category,
                priority: d.priority,
                titleVi: d.titleVi,
                actionRequiredVi: d.actionRequiredVi,
                locationLabel: d.locationLabel,
              })),
            })),
          }),
        });
        if (sumRes.ok) {
          executiveSummary = await sumRes.json();
        }
      } catch {
        // Summary synthesis is optional enhancement; per-page results remain intact
      }

      const newProject: DocumentProject = {
        id: `proj-${Date.now().toString(36)}`,
        fileName: file.name,
        fileSizeBytes: file.size,
        analyzedAt: new Date().toISOString(),
        totalPages: analyzedPages.length,
        pages: analyzedPages,
        executiveSummary,
      };

      setProgressPercent(100);
      setProject(newProject);
      setDirectivesCategoryFilter('all');
      setInspectorPageNumber(1);
      setInspectorDirectiveId(analyzedPages[0]?.directives[0]?.id);
      setActiveTab('summary');
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Đã xảy ra lỗi không xác định khi xử lý file PDF.'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLoadSample = async () => {
    setErrorMessage(null);
    setIsProcessing(true);
    setProgressText('Đang tạo tài liệu PDF mẫu bản vẽ cải tạo nội thất Tokyo...');
    setProgressPercent(3);
    try {
      const sampleFile = await generateSampleJapaneseInteriorPdf();
      await processPdfFile(sampleFile);
    } catch (err) {
      setIsProcessing(false);
      setErrorMessage(err instanceof Error ? err.message : 'Không thể tạo file mẫu.');
    }
  };

  const handleUpdateStatus = (directiveId: string, status: DirectiveStatus) => {
    if (!project) return;
    const allCurrent = project.pages.flatMap((p) => p.directives);
    const target = allCurrent.find((d) => d.id === directiveId);
    const prevStatus: DirectiveStatus = target?.status ?? 'todo';

    setProject((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        pages: prev.pages.map((page) => ({
          ...page,
          directives: page.directives.map((d) =>
            d.id === directiveId ? { ...d, status } : d
          ),
        })),
      };
    });

    if (status === 'done' && target) {
      const totalCount = allCurrent.length;
      const remainingAfter = allCurrent.filter(
        (d) => d.id !== directiveId && d.status !== 'done'
      ).length;
      const allDone = remainingAfter === 0 && totalCount > 0;

      showCompletionNotice({
        title: allDone
          ? `Hoàn thành toàn bộ ${totalCount}/${totalCount} chỉ thị!`
          : `Đã hoàn thành: ${target.titleVi}`,
        subtitle: allDone
          ? 'Tất cả hạng mục trong tài liệu đã được xử lý xong.'
          : `Còn ${remainingAfter} chỉ thị chưa hoàn thành.`,
        allDone,
        onUndo: () => {
          handleUpdateStatus(directiveId, prevStatus === 'done' ? 'todo' : prevStatus);
          setCompletionNotice(null);
        },
      });
    }
  };

  const handleUpdateDirectiveCrop = (
    pageNumber: number,
    directiveId: string,
    newBox: BoundingBox2D,
    newCroppedImageUrl: string
  ) => {
    setProject((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        pages: prev.pages.map((page) =>
          page.pageNumber === pageNumber
            ? {
                ...page,
                directives: page.directives.map((d) =>
                  d.id === directiveId
                    ? { ...d, box_2d: newBox, croppedImageUrl: newCroppedImageUrl }
                    : d
                ),
              }
            : page
        ),
      };
    });
  };

  const handleAddManualDirective = (pageNumber: number, newDirective: DirectiveItem) => {
    setProject((prev) => {
      if (!prev) return prev;
      const maxSeq = prev.pages
        .flatMap((p) => p.directives)
        .reduce((max, d) => Math.max(max, d.pdfSequence || 0), 0);
      const directiveWithSeq: DirectiveItem = {
        ...newDirective,
        pdfSequence: newDirective.pdfSequence > 0 ? newDirective.pdfSequence : maxSeq + 1,
      };
      return {
        ...prev,
        pages: prev.pages.map((page) =>
          page.pageNumber === pageNumber
            ? { ...page, directives: [...page.directives, directiveWithSeq] }
            : page
        ),
      };
    });
  };

  const navItems: Array<{ id: ActiveTab; label: string; requiresProject: boolean }> = [
    { id: 'summary', label: 'Tổng kết', requiresProject: true },
    { id: 'directives', label: 'Chỉ thị & Ảnh', requiresProject: true },
    { id: 'inspector', label: 'Bản vẽ gốc', requiresProject: true },
    { id: 'glossary', label: 'Thuật ngữ', requiresProject: false },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 no-print">
        <div className="max-w-[1440px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveTab(project ? 'summary' : 'upload')}
            className="text-lg font-bold tracking-tight text-slate-900 font-display whitespace-nowrap shrink-0 cursor-pointer"
          >
            Sekkei Brief
          </button>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            {navItems.map((item) => {
              const disabled = item.requiresProject && !project;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  disabled={disabled}
                  onClick={() => setActiveTab(item.id)}
                  className={`py-5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                    disabled
                      ? 'border-transparent text-slate-300 cursor-not-allowed'
                      : isActive
                      ? 'border-blue-700 text-slate-900 cursor-pointer'
                      : 'border-transparent text-slate-600 hover:text-slate-900 cursor-pointer'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              disabled={isProcessing}
              onClick={() => setActiveTab('upload')}
              className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Tải PDF mới
            </button>
          </div>
        </div>

        {/* Mobile sub-nav */}
        <div className="md:hidden border-t border-slate-100 px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium">
          {navItems.map((item) => {
            const disabled = item.requiresProject && !project;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                disabled={disabled}
                onClick={() => setActiveTab(item.id)}
                className={`py-1 whitespace-nowrap shrink-0 ${
                  disabled
                    ? 'text-slate-300'
                    : isActive
                    ? 'text-blue-700 font-semibold'
                    : 'text-slate-600'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {activeTab === 'upload' && (
          <UploadWorkspace
            isProcessing={isProcessing}
            progressText={progressText}
            progressPercent={progressPercent}
            errorMessage={errorMessage}
            onSelectFile={processPdfFile}
            onLoadSample={handleLoadSample}
            canRetry={Boolean(lastFile)}
            onRetry={() => {
              if (lastFile) processPdfFile(lastFile);
            }}
            hasExistingProject={Boolean(project)}
            onCancelToExisting={() => {
              if (project) setActiveTab('summary');
            }}
          />
        )}

        {activeTab === 'summary' && project && (
          <SummaryView
            project={project}
            onGoToDirectives={(cat) => {
              setDirectivesCategoryFilter(cat ?? 'all');
              setActiveTab('directives');
            }}
            onJumpToPage={(pageNum, directiveId) => {
              setInspectorPageNumber(pageNum);
              const firstDir = project.pages.find((p) => p.pageNumber === pageNum)?.directives[0];
              setInspectorDirectiveId(directiveId ?? firstDir?.id);
              setActiveTab('inspector');
            }}
            onUpdateStatus={handleUpdateStatus}
            onNotifyCompleted={(label, undo) =>
              showCompletionNotice({
                title: `Đã hoàn thành mục: ${label}`,
                subtitle: 'Mục vừa tick đã được đánh dấu hoàn tất.',
                onUndo: undo,
              })
            }
          />
        )}

        {activeTab === 'directives' && project && (
          <DirectivesView
            key={directivesCategoryFilter}
            project={project}
            initialCategoryFilter={directivesCategoryFilter}
            onUpdateStatus={handleUpdateStatus}
            onInspectDirective={(pageNum, directiveId) => {
              setInspectorPageNumber(pageNum);
              setInspectorDirectiveId(directiveId);
              setActiveTab('inspector');
            }}
          />
        )}

        {activeTab === 'inspector' && project && (
          <DrawingInspectorView
            project={project}
            initialPageNumber={inspectorPageNumber}
            initialDirectiveId={inspectorDirectiveId}
            onUpdateDirectiveCrop={handleUpdateDirectiveCrop}
            onAddManualDirective={handleAddManualDirective}
          />
        )}

        {activeTab === 'glossary' && <GlossaryView project={project} />}
      </main>

      {/* Completion Toast Notification */}
      {completionNotice && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 max-w-md w-[calc(100%-2.5rem)] rounded-xl bg-slate-900 text-white shadow-lg border border-slate-700 p-4 flex items-start gap-3 no-print"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold leading-snug">{completionNotice.title}</p>
            <p className="text-xs text-slate-300 mt-0.5">{completionNotice.subtitle}</p>
            {completionNotice.onUndo && (
              <button
                type="button"
                onClick={completionNotice.onUndo}
                className="mt-2 text-xs font-medium text-emerald-300 hover:text-emerald-200 underline underline-offset-2 cursor-pointer"
              >
                Hoàn tác
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={() => setCompletionNotice(null)}
            className="p-1 rounded text-slate-400 hover:text-white cursor-pointer"
            aria-label="Đóng thông báo"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
