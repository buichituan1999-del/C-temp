import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { jsPDF } from 'jspdf';
import type { BoundingBox2D } from '../types';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

export interface RenderedPdfPage {
  pageNumber: number;
  width: number;
  height: number;
  imageDataUrl: string;
  extractedText: string;
}

export async function renderPdfToPages(
  file: File,
  onProgress?: (currentPage: number, totalPages: number) => void
): Promise<RenderedPdfPage[]> {
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(arrayBuffer),
    cMapUrl: '/pdfjs/cmaps/',
    cMapPacked: true,
    standardFontDataUrl: '/pdfjs/standard_fonts/',
  });

  const pdf = await loadingTask.promise;
  const totalPages = pdf.numPages;
  const pages: RenderedPdfPage[] = [];

  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    onProgress?.(pageNum, totalPages);
    const page = await pdf.getPage(pageNum);
    const baseViewport = page.getViewport({ scale: 1 });
    // Target ~1550px on the longest edge (capped between 1.2x and 2.5x) for crisp Japanese Kanji & CAD details
    const targetScale = Math.min(2.5, Math.max(1.2, 1550 / Math.max(baseViewport.width, baseViewport.height)));
    const viewport = page.getViewport({ scale: targetScale });

    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Không thể khởi tạo Canvas 2D để xử lý trang PDF.');
    }

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    await page.render({
      canvas,
      canvasContext: ctx,
      viewport,
    }).promise;

    const textContent = await page.getTextContent();
    const extractedText = textContent.items
      .map((item) => ('str' in item ? item.str : ''))
      .filter(Boolean)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();

    const imageDataUrl = canvas.toDataURL('image/jpeg', 0.88);
    pages.push({
      pageNumber: pageNum,
      width: canvas.width,
      height: canvas.height,
      imageDataUrl,
      extractedText,
    });
  }

  return pages;
}

export async function cropDirectiveFromPage(
  pageImageDataUrl: string,
  box2d: BoundingBox2D,
  paddingRatio = 0.025
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const [rawYmin, rawXmin, rawYmax, rawXmax] = box2d;
      const pad = paddingRatio * 1000;
      const ymin = Math.max(0, rawYmin - pad);
      const xmin = Math.max(0, rawXmin - pad);
      const ymax = Math.min(1000, rawYmax + pad);
      const xmax = Math.min(1000, rawXmax + pad);

      const sx = Math.round((xmin / 1000) * img.naturalWidth);
      const sy = Math.round((ymin / 1000) * img.naturalHeight);
      const sw = Math.max(40, Math.round(((xmax - xmin) / 1000) * img.naturalWidth));
      const sh = Math.max(40, Math.round(((ymax - ymin) / 1000) * img.naturalHeight));

      const cropCanvas = document.createElement('canvas');
      cropCanvas.width = sw;
      cropCanvas.height = sh;
      const ctx = cropCanvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Không thể tạo canvas cắt ảnh.'));
        return;
      }

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, sw, sh);
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      resolve(cropCanvas.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('Không thể tải ảnh trang PDF để cắt vùng chỉ thị.'));
    img.src = pageImageDataUrl;
  });
}

function drawRedCloud(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.save();
  ctx.strokeStyle = '#dc2626';
  ctx.lineWidth = 3;
  ctx.beginPath();
  const bumpsX = Math.max(4, Math.round(w / 45));
  const bumpsY = Math.max(3, Math.round(h / 45));
  const stepX = w / bumpsX;
  const stepY = h / bumpsY;

  for (let i = 0; i < bumpsX; i++) {
    const cx = x + i * stepX + stepX / 2;
    ctx.arc(cx, y, stepX * 0.52, Math.PI, 0, false);
  }
  for (let i = 0; i < bumpsY; i++) {
    const cy = y + i * stepY + stepY / 2;
    ctx.arc(x + w, cy, stepY * 0.52, -Math.PI / 2, Math.PI / 2, false);
  }
  for (let i = bumpsX - 1; i >= 0; i--) {
    const cx = x + i * stepX + stepX / 2;
    ctx.arc(cx, y + h, stepX * 0.52, 0, Math.PI, false);
  }
  for (let i = bumpsY - 1; i >= 0; i--) {
    const cy = y + i * stepY + stepY / 2;
    ctx.arc(x, cy, stepY * 0.52, Math.PI / 2, -Math.PI / 2, false);
  }
  ctx.stroke();
  ctx.restore();
}

export async function generateSampleJapaneseInteriorPdf(): Promise<File> {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'px',
    format: [1400, 990],
  });

  // Page 1: LDK Floorplan & Redline Directives
  const c1 = document.createElement('canvas');
  c1.width = 1400;
  c1.height = 990;
  const g1 = c1.getContext('2d')!;
  g1.fillStyle = '#ffffff';
  g1.fillRect(0, 0, 1400, 990);

  // Outer drawing border & title block
  g1.strokeStyle = '#1e293b';
  g1.lineWidth = 3;
  g1.strokeRect(32, 32, 1336, 926);
  g1.lineWidth = 1.5;
  g1.strokeRect(42, 42, 1316, 906);

  // Title Block bottom-right
  g1.strokeRect(940, 828, 418, 120);
  g1.beginPath();
  g1.moveTo(940, 868);
  g1.lineTo(1358, 868);
  g1.moveTo(940, 908);
  g1.lineTo(1358, 908);
  g1.stroke();
  g1.fillStyle = '#0f172a';
  g1.font = 'bold 20px "Noto Sans JP", sans-serif';
  g1.fillText('青山レジデンス 302号室 内装改修工事', 958, 855);
  g1.font = '16px "Noto Sans JP", sans-serif';
  g1.fillText('図面名称：LDK 平面図・赤チェック修正指示', 958, 895);
  g1.fillText('縮尺 S=1/50   |   日付：2026.11.20   |   A-01', 958, 935);

  // Grid & architectural walls
  g1.strokeStyle = '#334155';
  g1.lineWidth = 6;
  g1.strokeRect(110, 120, 860, 620);
  // Inner room partition
  g1.lineWidth = 4;
  g1.beginPath();
  g1.moveTo(110, 410);
  g1.lineTo(380, 410);
  g1.stroke();

  // Room label
  g1.fillStyle = '#475569';
  g1.font = 'bold 22px "Noto Sans JP", sans-serif';
  g1.fillText('LDK (約24.5帖)  FL+0', 480, 165);

  // 1. Kitchen Island (top-left/center)
  g1.fillStyle = '#f1f5f9';
  g1.fillRect(210, 210, 320, 115);
  g1.strokeStyle = '#0f172a';
  g1.lineWidth = 2;
  g1.strokeRect(210, 210, 320, 115);
  g1.strokeRect(245, 232, 95, 65); // Sink
  g1.strokeRect(390, 232, 95, 65); // IH stove
  g1.fillStyle = '#0f172a';
  g1.font = '15px "Noto Sans JP", sans-serif';
  g1.fillText('アイランドキッチン W2400×D900', 225, 348);

  // Redline directive 1 around Kitchen Island
  drawRedCloud(g1, 185, 190, 370, 175);
  g1.fillStyle = '#dc2626';
  g1.font = 'bold 18px "Noto Sans JP", sans-serif';
  g1.fillText('①【至急変更】天板を人工大理石コーリアン', 575, 225);
  g1.fillText('（グレーシャーホワイト）へ変更すること。', 575, 250);
  g1.fillText('シンク位置を左へ100mm移動。', 575, 275);
  g1.strokeStyle = '#dc2626';
  g1.lineWidth = 2.5;
  g1.beginPath();
  g1.moveTo(570, 240);
  g1.lineTo(525, 255);
  g1.stroke();

  // 2. Dining Table
  g1.fillStyle = '#f8fafc';
  g1.fillRect(580, 410, 230, 120);
  g1.strokeStyle = '#0f172a';
  g1.lineWidth = 2;
  g1.strokeRect(580, 410, 230, 120);
  g1.fillStyle = '#0f172a';
  g1.font = '15px "Noto Sans JP", sans-serif';
  g1.fillText('ダイニングテーブル W1800×D900', 585, 475);

  // 3. TV Wall & Cabinet (bottom-left)
  g1.fillStyle = '#e2e8f0';
  g1.fillRect(140, 620, 360, 75);
  g1.strokeStyle = '#0f172a';
  g1.strokeRect(140, 620, 360, 75);
  g1.fillStyle = '#0f172a';
  g1.font = '15px "Noto Sans JP", sans-serif';
  g1.fillText('造作TVボード W2600×D450', 220, 663);

  // Redline directive 2 around TV cabinet
  drawRedCloud(g1, 125, 600, 395, 115);
  g1.fillStyle = '#dc2626';
  g1.font = 'bold 18px "Noto Sans JP", sans-serif';
  g1.fillText('②【新規造作＋サイズ修正】', 140, 760);
  g1.fillText('・TVボード奥行きを D450 → D380 に縮小。', 140, 788);
  g1.fillText('・背面壁に間接照明用ふかし壁(t=60)を新規追加。', 140, 816);
  g1.beginPath();
  g1.moveTo(260, 738);
  g1.lineTo(290, 700);
  g1.stroke();

  // 4. Right side general notes & clarification
  g1.strokeStyle = '#64748b';
  g1.lineWidth = 1.5;
  g1.strokeRect(995, 120, 335, 380);
  g1.fillStyle = '#0f172a';
  g1.font = 'bold 18px "Noto Sans JP", sans-serif';
  g1.fillText('特記仕様・確認事項', 1015, 155);
  g1.font = '15px "Noto Sans JP", sans-serif';
  g1.fillText('1. 床材：オーク挽板フローリング', 1015, 195);
  g1.fillText('   (t=15mm ナチュラルオイル仕上げ)', 1015, 220);
  g1.fillText('2. 巾木：アルミ見切り巾木 H40 黒', 1015, 260);
  g1.fillText('3. 天井高さ：CH=2550mm 統一', 1015, 300);
  g1.fillStyle = '#b45309';
  g1.font = 'bold 16px "Noto Sans JP", sans-serif';
  g1.fillText('③【要確認】リビング入口建具の', 1015, 355);
  g1.fillText('ガラス種類（クリア vs 複層カスミ）を', 1015, 380);
  g1.fillText('施主様へ最終確認すること。', 1015, 405);

  doc.addImage(c1.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 1400, 990);

  // Page 2: Millwork Elevation & Material Schedule
  doc.addPage([1400, 990], 'landscape');
  const c2 = document.createElement('canvas');
  c2.width = 1400;
  c2.height = 990;
  const g2 = c2.getContext('2d')!;
  g2.fillStyle = '#ffffff';
  g2.fillRect(0, 0, 1400, 990);

  g2.strokeStyle = '#1e293b';
  g2.lineWidth = 3;
  g2.strokeRect(32, 32, 1336, 926);

  g2.fillStyle = '#0f172a';
  g2.font = 'bold 24px "Noto Sans JP", sans-serif';
  g2.fillText('造作キッチン背面収納 詳細展開図・仕上表 (A-02)', 70, 90);

  // Cabinet Elevation
  g2.strokeStyle = '#0f172a';
  g2.lineWidth = 2.5;
  g2.strokeRect(110, 160, 620, 480);
  // Upper cabinets
  g2.strokeRect(110, 160, 206, 170);
  g2.strokeRect(316, 160, 206, 170);
  g2.strokeRect(522, 160, 208, 170);
  // Open niche counter
  g2.fillStyle = '#f1f5f9';
  g2.fillRect(110, 330, 620, 130);
  g2.strokeRect(110, 330, 620, 130);
  // Lower drawers
  g2.strokeRect(110, 460, 206, 180);
  g2.strokeRect(316, 460, 206, 180);
  g2.strokeRect(522, 460, 208, 180);

  g2.fillStyle = '#334155';
  g2.font = '16px "Noto Sans JP", sans-serif';
  g2.fillText('W2400  |  総高 H2350  |  カウンター H850', 220, 680);

  // Redline on Upper Cabinets
  drawRedCloud(g2, 95, 145, 650, 200);
  g2.fillStyle = '#dc2626';
  g2.font = 'bold 18px "Noto Sans JP", sans-serif';
  g2.fillText('④【仕様変更】吊戸棚面材：', 780, 205);
  g2.fillText('アイカ メラミン化粧板 TJ-10234K (ウォールナット柄)', 780, 235);
  g2.fillText('取手レス（J型手掛け加工）に変更。', 780, 265);
  g2.strokeStyle = '#dc2626';
  g2.beginPath();
  g2.moveTo(775, 225);
  g2.lineTo(735, 225);
  g2.stroke();

  // Redline on Open Niche
  drawRedCloud(g2, 95, 335, 650, 120);
  g2.fillText('⑤【納まり修正】コンセント2口×2箇所を追加。', 780, 385);
  g2.fillText('LEDライン照明 (3000K 電球色) を吊戸棚底面に埋込。', 780, 415);
  g2.beginPath();
  g2.moveTo(775, 395);
  g2.lineTo(735, 395);
  g2.stroke();

  // Material Schedule Table bottom right
  g2.strokeStyle = '#334155';
  g2.lineWidth = 1.5;
  g2.strokeRect(780, 500, 540, 260);
  g2.fillStyle = '#0f172a';
  g2.font = 'bold 17px "Noto Sans JP", sans-serif';
  g2.fillText('仕上・金物リスト（厳守）', 800, 535);
  g2.font = '15px "Noto Sans JP", sans-serif';
  g2.fillText('・スライドレール：BLUM タンデムボックス（ソフトクローズ付）', 800, 575);
  g2.fillText('・蝶番：LAMP オリンピアスライド丁番 105°開き', 800, 610);
  g2.fillText('・カウンター見切り：アルミL型アングル 艶消し黒', 800, 645);
  g2.fillText('・塗装：ウレタンクリア全艶消し（木口テープ不可）', 800, 680);

  doc.addImage(c2.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 1400, 990);

  const pdfBlob = doc.output('blob');
  return new File([pdfBlob], 'Aoyama_302_Interior_Redline_Sample.pdf', {
    type: 'application/pdf',
  });
}
