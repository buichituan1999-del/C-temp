import {
  CATEGORY_LABELS,
  DocumentProject,
  formatDirectiveNumber,
  PRIORITY_LABELS,
  STATUS_LABELS,
} from '../types';

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function downloadDataUrl(dataUrl: string, filename: string) {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportProjectReportHtml(project: DocumentProject) {
  const allDirectives = project.pages.flatMap((p) => p.directives);
  const summary = project.executiveSummary;

  const html = `<!doctype html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <title>Báo cáo Chỉ thị Nội thất — ${escapeHtml(project.fileName)}</title>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; color: #0f172a; max-width: 1080px; margin: 32px auto; padding: 0 24px; line-height: 1.55; }
    h1 { font-size: 24px; margin-bottom: 6px; }
    h2 { font-size: 18px; margin-top: 28px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; }
    .meta { color: #475569; font-size: 13px; margin-bottom: 24px; }
    .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 16px 0; }
    .box { border: 1px solid #cbd5e1; border-radius: 8px; padding: 14px 16px; background: #f8fafc; }
    .box h3 { font-size: 14px; margin: 0 0 8px 0; color: #1e293b; }
    ul { margin: 0; padding-left: 18px; font-size: 14px; }
    li { margin-bottom: 4px; }
    .directive { border: 1px solid #cbd5e1; border-radius: 10px; padding: 16px; margin-bottom: 16px; display: grid; grid-template-columns: 1.3fr 1fr; gap: 16px; break-inside: avoid; }
    .directive img { width: 100%; max-height: 280px; object-fit: contain; border: 1px solid #e2e8f0; border-radius: 6px; background: #fff; }
    .d-meta { font-size: 12px; color: #475569; margin-bottom: 6px; }
    .d-title { font-size: 16px; font-weight: 700; margin: 0 0 8px 0; }
    .jp-quote { font-size: 13px; background: #f1f5f9; padding: 8px 10px; border-radius: 6px; margin-top: 8px; color: #334155; }
    .specs { font-family: monospace; font-size: 12px; color: #1e40af; margin-top: 8px; }
    @media print { body { margin: 12px; } }
  </style>
</head>
<body>
  <h1>${escapeHtml(summary?.projectTitleVi || project.fileName)}</h1>
  <div class="meta">Tệp gốc: ${escapeHtml(project.fileName)} · ${project.totalPages} trang · ${allDirectives.length} chỉ thị trích xuất</div>

  ${
    summary
      ? `<p>${escapeHtml(summary.clientContextVi)}</p>
         <div class="summary-grid">
           <div class="box"><h3>Việc ưu tiên hàng đầu</h3><ul>${summary.topPrioritiesVi.map((x) => `<li>${escapeHtml(x)}</li>`).join('')}</ul></div>
           <div class="box"><h3>Cần chỉnh sửa</h3><ul>${summary.revisionsSummaryVi.map((x) => `<li>${escapeHtml(x)}</li>`).join('')}</ul></div>
           <div class="box"><h3>Làm mới / Bổ sung</h3><ul>${summary.newWorkSummaryVi.map((x) => `<li>${escapeHtml(x)}</li>`).join('')}</ul></div>
           <div class="box"><h3>Cần hỏi xác nhận lại</h3><ul>${summary.clarificationsNeededVi.map((x) => `<li>${escapeHtml(x)}</li>`).join('')}</ul></div>
         </div>`
      : ''
  }

  <h2>Danh sách Chỉ thị Chi tiết & Hình ảnh Chụp từ Bản vẽ (${allDirectives.length})</h2>
  ${allDirectives
    .map(
      (d) => `
    <div class="directive">
      <div>
        <div class="d-meta">
          Chỉ thị ${escapeHtml(formatDirectiveNumber(d))} · Trang ${d.pageNumber} · ${escapeHtml(CATEGORY_LABELS[d.category])} · ${escapeHtml(PRIORITY_LABELS[d.priority])} · ${escapeHtml(STATUS_LABELS[d.status])} · ${escapeHtml(d.locationLabel)}
        </div>
        <h3 class="d-title">${escapeHtml(d.titleVi)}</h3>
        <div>${escapeHtml(d.actionRequiredVi)}</div>
        ${d.specs.length > 0 ? `<div class="specs">Thông số / Mã: ${escapeHtml(d.specs.join(' | '))}</div>` : ''}
        ${d.japaneseQuote ? `<div class="jp-quote"><strong>Nguyên văn tiếng Nhật:</strong> ${escapeHtml(d.japaneseQuote)}</div>` : ''}
      </div>
      <div>
        ${d.croppedImageUrl ? `<img src="${d.croppedImageUrl}" alt="${escapeHtml(d.titleVi)}" />` : ''}
      </div>
    </div>
  `
    )
    .join('')}
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const safeBase = project.fileName.replace(/\.pdf$/i, '').replace(/[^a-zA-Z0-9_-]/g, '_');
  link.download = `${safeBase}_BaoCao_ChiThi_NoiThat.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
