export type DirectiveCategory = 'edit' | 'create' | 'material' | 'dimension' | 'verify';

export type DirectivePriority = 'urgent' | 'important' | 'normal';

export type DirectiveStatus = 'todo' | 'in_progress' | 'done';

/**
 * Normalized bounding box in 0..1000 coordinate space: [ymin, xmin, ymax, xmax]
 */
export type BoundingBox2D = [number, number, number, number];

export interface DirectiveItem {
  id: string;
  pageNumber: number;
  pdfSequence: number;
  pdfMark?: string;
  category: DirectiveCategory;
  priority: DirectivePriority;
  status: DirectiveStatus;
  titleVi: string;
  actionRequiredVi: string;
  japaneseQuote: string;
  locationLabel: string;
  specs: string[];
  box_2d: BoundingBox2D;
  croppedImageUrl?: string;
  isManualCrop?: boolean;
}

export function formatDirectiveNumber(item: Pick<DirectiveItem, 'pdfSequence' | 'pdfMark'>): string {
  const mark = item.pdfMark?.trim();
  if (mark) {
    return mark;
  }
  return String(item.pdfSequence).padStart(2, '0');
}

export interface TranslationBlock {
  id: string;
  sectionLabel: string;
  japaneseOriginal: string;
  vietnameseTranslation: string;
  contextNote: string;
}

export interface GlossaryTerm {
  japanese: string;
  reading: string;
  vietnamese: string;
  note: string;
}

export interface AnalyzedPage {
  pageNumber: number;
  width: number;
  height: number;
  imageDataUrl: string;
  extractedText: string;
  documentTypeVi: string;
  pageTitleVi: string;
  pageSummaryVi: string;
  translationBlocks: TranslationBlock[];
  directives: DirectiveItem[];
  glossaryTerms: GlossaryTerm[];
}

export interface ExecutiveSummary {
  projectTitleVi: string;
  clientContextVi: string;
  topPrioritiesVi: string[];
  revisionsSummaryVi: string[];
  newWorkSummaryVi: string[];
  clarificationsNeededVi: string[];
}

export interface DocumentProject {
  id: string;
  fileName: string;
  fileSizeBytes: number;
  analyzedAt: string;
  totalPages: number;
  pages: AnalyzedPage[];
  executiveSummary: ExecutiveSummary | null;
}

export const CATEGORY_LABELS: Record<DirectiveCategory, string> = {
  edit: 'Chỉnh sửa',
  create: 'Làm mới / Bổ sung',
  material: 'Vật liệu / Mã màu',
  dimension: 'Kích thước / Kỹ thuật',
  verify: 'Cần xác nhận lại',
};

export const PRIORITY_LABELS: Record<DirectivePriority, string> = {
  urgent: 'Khẩn cấp',
  important: 'Quan trọng',
  normal: 'Thông thường',
};

export const STATUS_LABELS: Record<DirectiveStatus, string> = {
  todo: 'Chưa làm',
  in_progress: 'Đang sửa',
  done: 'Đã xong',
};
