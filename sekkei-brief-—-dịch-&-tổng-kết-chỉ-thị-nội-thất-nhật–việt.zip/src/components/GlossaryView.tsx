import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { DocumentProject, GlossaryTerm } from '../types';

interface GlossaryViewProps {
  project: DocumentProject | null;
}

const CORE_INTERIOR_GLOSSARY: GlossaryTerm[] = [
  {
    japanese: '造作家具',
    reading: 'ぞうさくかぐ · Zousaku Kagu',
    vietnamese: 'Đồ nội thất đóng đo theo thiết kế (Millwork / Built-in)',
    note: 'Tủ bếp, tủ TV, quầy lễ tân sản xuất riêng theo bản vẽ chi tiết.',
  },
  {
    japanese: 'メラミン化粧板',
    reading: 'メラミンけしょうばん · Meramin Keshouban',
    vietnamese: 'Tấm phủ bề mặt Melamine / Laminate (AICA, Ibiden...)',
    note: 'Thường ghi kèm mã hãng như TJ-10234K, K-6000KN.',
  },
  {
    japanese: '突板',
    reading: 'つきいた · Tsukiita',
    vietnamese: 'Gỗ lạng tự nhiên phủ bề mặt (Veneer)',
    note: 'Cần chú ý hướng vân gỗ (木目方向: 縦目 vân dọc / 横目 vân ngang).',
  },
  {
    japanese: '人工大理石',
    reading: 'じんこうだいりせき · Jinkou Dairiseki',
    vietnamese: 'Đá nhân tạo (Solid Surface / Corian)',
    note: 'Phổ biến cho mặt bàn bếp, lavabo liền khối tại Nhật.',
  },
  {
    japanese: '巾木',
    reading: 'はばき · Habaki',
    vietnamese: 'Len chân tường / Phào chân tủ',
    note: 'Ví dụ: アルミ巾木 (len nhôm), ソフト巾木 (len nhựa dẻo).',
  },
  {
    japanese: '見切り材',
    reading: 'みきりざい · Mikirizai',
    vietnamese: 'Nẹp kết thúc / Nẹp chuyển tiếp vật liệu',
    note: 'Dùng ở điểm giao giữa 2 loại sàn hoặc mép ốp tường.',
  },
  {
    japanese: '納まり',
    reading: 'おさまり · Osamari',
    vietnamese: 'Chi tiết giao cắt / Kỹ thuật lắp ghép hoàn thiện',
    note: 'Khách Nhật rất chú trọng độ khít, khe hở (目地) và thẩm mỹ mối nối.',
  },
  {
    japanese: 'ふかし壁',
    reading: 'ふかしかべ · Fukashi Kabe',
    vietnamese: 'Vách dựng dày thêm (để giấu đường ống / đèn LED gián tiếp)',
    note: 'Thường ghi rõ độ dày t=50, t=60 hoặc t=100mm.',
  },
  {
    japanese: '赤チェック / 朱書き',
    reading: 'あかチェック · Aka Chekku',
    vietnamese: 'Ghi chú kiểm tra / Chỉ thị chỉnh sửa mực đỏ (Redline)',
    note: 'Các nội dung khoanh đám mây đỏ cần ưu tiên sửa bản vẽ ngay.',
  },
  {
    japanese: 'FL / GL / CH',
    reading: 'Floor Level / Ground Level / Ceiling Height',
    vietnamese: 'Cao độ sàn hoàn thiện / Cao độ mặt đất / Chiều cao trần',
    note: 'Đơn vị mặc định trên bản vẽ nội thất Nhật là mm.',
  },
  {
    japanese: '丁番 / スライドレール',
    reading: 'ちょうばん / スライドレール',
    vietnamese: 'Bản lề / Ray trượt ngăn kéo',
    note: 'Thường chỉ định hãng LAMP (Sugatsume), BLUM, Hettich.',
  },
  {
    japanese: '木口テープ / 木口処理',
    reading: 'こぐちテープ · Koguchi Teepu',
    vietnamese: 'Nẹp dán cạnh gỗ / Xử lý cạnh ván',
    note: 'Ghi chú loại dán cạnh PVC, Melamine hay sơn cạnh.',
  },
];

export const GlossaryView: React.FC<GlossaryViewProps> = ({ project }) => {
  const [query, setQuery] = useState('');

  const documentTerms = useMemo(() => {
    if (!project) return [];
    const seen = new Set<string>();
    const list: GlossaryTerm[] = [];
    for (const page of project.pages) {
      for (const term of page.glossaryTerms) {
        const key = term.japanese.trim();
        if (key && !seen.has(key)) {
          seen.add(key);
          list.push(term);
        }
      }
    }
    return list;
  }, [project]);

  const filterList = (items: GlossaryTerm[]) => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (t) =>
        t.japanese.toLowerCase().includes(q) ||
        t.reading.toLowerCase().includes(q) ||
        t.vietnamese.toLowerCase().includes(q) ||
        t.note.toLowerCase().includes(q)
    );
  };

  const filteredDocTerms = filterList(documentTerms);
  const filteredCoreTerms = filterList(CORE_INTERIOR_GLOSSARY);

  return (
    <div className="max-w-5xl mx-auto px-6 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-slate-200">
        <div>
          <p className="text-xs text-slate-500 mb-1">
            Tra cứu nhanh ký hiệu bản vẽ, vật liệu & phụ kiện nội thất Nhật Bản
          </p>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Thuật ngữ nội thất Nhật – Việt
          </h1>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm Kanji, phiên âm, tiếng Việt..."
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      {project && documentTerms.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-base font-semibold text-slate-900">
            Thuật ngữ trích xuất từ file đang mở ({filteredDocTerms.length})
          </h2>
          <div className="overflow-x-auto bg-white border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-4 font-medium w-44">Tiếng Nhật</th>
                  <th className="py-2.5 px-4 font-medium w-48">Phiên âm</th>
                  <th className="py-2.5 px-4 font-medium w-60">Nghĩa tiếng Việt</th>
                  <th className="py-2.5 px-4 font-medium">Ghi chú thực tế</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredDocTerms.map((t, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-semibold text-slate-900">{t.japanese}</td>
                    <td className="py-3 px-4 text-xs text-slate-500">{t.reading}</td>
                    <td className="py-3 px-4 font-medium text-blue-800">{t.vietnamese}</td>
                    <td className="py-3 px-4 text-slate-600">{t.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">
          Bộ thuật ngữ chuẩn thường gặp trong bản vẽ nội thất Nhật ({filteredCoreTerms.length})
        </h2>
        <div className="overflow-x-auto bg-white border border-slate-200 rounded-xl">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500">
                <th className="py-2.5 px-4 font-medium w-44">Tiếng Nhật</th>
                <th className="py-2.5 px-4 font-medium w-48">Phiên âm</th>
                <th className="py-2.5 px-4 font-medium w-60">Nghĩa tiếng Việt</th>
                <th className="py-2.5 px-4 font-medium">Ghi chú thực tế</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredCoreTerms.map((t, idx) => (
                <tr key={idx} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-semibold text-slate-900">{t.japanese}</td>
                  <td className="py-3 px-4 text-xs text-slate-500">{t.reading}</td>
                  <td className="py-3 px-4 font-medium text-slate-900">{t.vietnamese}</td>
                  <td className="py-3 px-4 text-slate-600">{t.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
