import React, { useRef, useState } from 'react';
import { Upload, FileText, ArrowRight, Loader2, AlertCircle } from 'lucide-react';

interface UploadWorkspaceProps {
  isProcessing: boolean;
  progressText: string;
  progressPercent: number;
  errorMessage: string | null;
  onSelectFile: (file: File) => void;
  onLoadSample: () => void;
  canRetry: boolean;
  onRetry: () => void;
  hasExistingProject: boolean;
  onCancelToExisting: () => void;
}

export const UploadWorkspace: React.FC<UploadWorkspaceProps> = ({
  isProcessing,
  progressText,
  progressPercent,
  errorMessage,
  onSelectFile,
  onLoadSample,
  canRetry,
  onRetry,
  hasExistingProject,
  onCancelToExisting,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onSelectFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (isProcessing) return;
    const file = e.dataTransfer.files?.[0];
    if (file && (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'))) {
      onSelectFile(file);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <p className="text-xs font-medium text-blue-700 tracking-wide mb-2">
            Hồ sơ thiết kế · Chỉ thị Redline · Chi tiết đồ gỗ nội thất Nhật–Việt
          </p>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-900 max-w-2xl text-balance">
            Dịch bản vẽ PDF tiếng Nhật, tổng kết đầu việc & chụp vùng chỉ thị
          </h1>
        </div>
        {hasExistingProject && !isProcessing && (
          <button
            type="button"
            onClick={onCancelToExisting}
            className="text-sm font-medium text-slate-600 hover:text-slate-900 underline underline-offset-4 whitespace-nowrap shrink-0 self-start md:self-auto"
          >
            Quay lại tài liệu đang xem
          </button>
        )}
      </div>

      {errorMessage && (
        <div
          role="alert"
          className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-lg border border-red-200 bg-red-50 text-red-900 text-sm"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Không thể xử lý tài liệu PDF</p>
              <p className="text-red-800 mt-0.5">{errorMessage}</p>
            </div>
          </div>
          {canRetry && !isProcessing && (
            <button
              type="button"
              onClick={onRetry}
              className="px-3.5 py-1.5 rounded-md bg-red-700 text-white text-xs font-medium hover:bg-red-800 whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer"
            >
              Thử phân tích lại
            </button>
          )}
        </div>
      )}

      <div
        onDragOver={(e) => {
          e.preventDefault();
          if (!isProcessing) setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`rounded-xl border bg-white p-8 md:p-12 transition-colors ${
          isDragging
            ? 'border-blue-600 bg-blue-50/40'
            : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,.pdf"
          onChange={handleFileChange}
          className="hidden"
          disabled={isProcessing}
        />

        {isProcessing ? (
          <div className="py-8 max-w-xl mx-auto text-center">
            <Loader2 className="w-9 h-9 text-blue-700 animate-spin mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-900 mb-2">
              Đang đọc bản vẽ & trích xuất chỉ thị tiếng Nhật
            </h2>
            <p className="text-sm text-slate-600 mb-5">{progressText}</p>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-700 transition-all duration-300"
                style={{ width: `${Math.max(5, Math.min(100, progressPercent))}%` }}
              />
            </div>
            <p className="mt-2 text-xs font-mono tabular-nums text-slate-500">
              {Math.round(progressPercent)}% hoàn thành
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center mb-5">
              <Upload className="w-5 h-5 text-slate-700" />
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">
              Kéo thả file PDF từ khách hàng Nhật vào đây
            </h2>
            <p className="text-sm text-slate-600 max-w-lg mb-7">
              Hỗ trợ mặt bằng CAD xuất PDF, bản vẽ chi tiết đồ gỗ (造作図), file scan có ghi chú viết tay màu đỏ (赤チェック), và bảng chỉ định vật liệu (仕上表).
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-700 text-white text-sm font-medium hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                Chọn file PDF từ máy tính
              </button>

              <button
                type="button"
                onClick={onLoadSample}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm font-medium hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Dùng thử PDF nội thất Nhật mẫu
                <ArrowRight className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="p-5 rounded-xl bg-white border border-slate-200">
          <p className="text-xs font-mono tabular-nums text-slate-400 mb-2">01</p>
          <h3 className="text-sm font-semibold text-slate-900 mb-1.5">
            Dịch chuẩn thuật ngữ nội thất Nhật
          </h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Nhận diện cả văn bản PDF lẫn chữ viết tay trên ảnh scan, dịch chính xác thuật ngữ như Melamine, gỗ lạng, len chân tường, cao độ FL/CH.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200">
          <p className="text-xs font-mono tabular-nums text-slate-400 mb-2">02</p>
          <h3 className="text-sm font-semibold text-slate-900 mb-1.5">
            Tổng kết việc cần làm & chỉnh sửa
          </h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Tự động phân nhóm đầu việc: cần chỉnh sửa bản vẽ gì, làm mới hạng mục nào, đổi mã vật liệu gì và điểm nào cần hỏi lại khách.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200">
          <p className="text-xs font-mono tabular-nums text-slate-400 mb-2">03</p>
          <h3 className="text-sm font-semibold text-slate-900 mb-1.5">
            Chụp cắt hình ảnh vùng chỉ thị
          </h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Khoanh vùng và cắt ảnh từng vị trí khách yêu cầu trên bản vẽ để gửi ngay cho họa viên CAD hoặc xưởng sản xuất xem trực quan.
          </p>
        </div>
      </div>
    </div>
  );
};
