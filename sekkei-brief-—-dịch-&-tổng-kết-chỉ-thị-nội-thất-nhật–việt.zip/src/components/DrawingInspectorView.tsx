import React, { useEffect, useRef, useState } from 'react';
import {
  Crop,
  Download,
  Loader2,
  Plus,
  Sparkles,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  BoundingBox2D,
  CATEGORY_LABELS,
  DirectiveItem,
  DocumentProject,
  formatDirectiveNumber,
  PRIORITY_LABELS,
} from '../types';
import { cropDirectiveFromPage } from '../utils/pdfProcessor';
import { downloadDataUrl } from '../utils/exportReport';

interface DrawingInspectorViewProps {
  project: DocumentProject;
  initialPageNumber?: number;
  initialDirectiveId?: string;
  onUpdateDirectiveCrop: (
    pageNumber: number,
    directiveId: string,
    newBox: BoundingBox2D,
    newCroppedImageUrl: string
  ) => void;
  onAddManualDirective: (pageNumber: number, newDirective: DirectiveItem) => void;
}

export const DrawingInspectorView: React.FC<DrawingInspectorViewProps> = ({
  project,
  initialPageNumber = 1,
  initialDirectiveId,
  onUpdateDirectiveCrop,
  onAddManualDirective,
}) => {
  const [selectedPageNum, setSelectedPageNum] = useState<number>(initialPageNumber);
  const [selectedDirectiveId, setSelectedDirectiveId] = useState<string | null>(
    initialDirectiveId ?? null
  );
  const [zoomPercent, setZoomPercent] = useState<number>(100);
  const [isDrawMode, setIsDrawMode] = useState<boolean>(false);

  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [dragCurrent, setDragCurrent] = useState<{ x: number; y: number } | null>(null);
  const [pendingBox, setPendingBox] = useState<BoundingBox2D | null>(null);
  const [pendingCropUrl, setPendingCropUrl] = useState<string | null>(null);

  const [customTitle, setCustomTitle] = useState('');
  const [isTranslatingRegion, setIsTranslatingRegion] = useState(false);
  const [regionAiResult, setRegionAiResult] = useState<string | null>(null);

  const imageContainerRef = useRef<HTMLDivElement>(null);

  const activePage =
    project.pages.find((p) => p.pageNumber === selectedPageNum) ?? project.pages[0];

  useEffect(() => {
    setSelectedPageNum(initialPageNumber);
  }, [initialPageNumber]);

  useEffect(() => {
    if (initialDirectiveId) {
      setSelectedDirectiveId(initialDirectiveId);
    } else if (activePage?.directives.length > 0 && !selectedDirectiveId) {
      setSelectedDirectiveId(activePage.directives[0].id);
    }
  }, [initialDirectiveId, activePage, selectedDirectiveId]);

  if (!activePage) return null;

  const selectedDirective =
    activePage.directives.find((d) => d.id === selectedDirectiveId) ?? null;

  const getNormalizedCoords = (clientX: number, clientY: number) => {
    const el = imageContainerRef.current;
    if (!el) return { x: 0, y: 0 };
    const rect = el.getBoundingClientRect();
    const x = Math.max(0, Math.min(1000, ((clientX - rect.left) / rect.width) * 1000));
    const y = Math.max(0, Math.min(1000, ((clientY - rect.top) / rect.height) * 1000));
    return { x: Math.round(x), y: Math.round(y) };
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDrawMode) return;
    e.preventDefault();
    const pt = getNormalizedCoords(e.clientX, e.clientY);
    setDragStart(pt);
    setDragCurrent(pt);
    setPendingBox(null);
    setPendingCropUrl(null);
    setRegionAiResult(null);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDrawMode || !dragStart) return;
    setDragCurrent(getNormalizedCoords(e.clientX, e.clientY));
  };

  const handleMouseUp = async () => {
    if (!isDrawMode || !dragStart || !dragCurrent) return;
    const ymin = Math.min(dragStart.y, dragCurrent.y);
    const xmin = Math.min(dragStart.x, dragCurrent.x);
    const ymax = Math.max(dragStart.y, dragCurrent.y);
    const xmax = Math.max(dragStart.x, dragCurrent.x);

    setDragStart(null);
    setDragCurrent(null);

    if (ymax - ymin < 15 || xmax - xmin < 15) {
      return;
    }

    const box: BoundingBox2D = [ymin, xmin, ymax, xmax];
    setPendingBox(box);
    const cropped = await cropDirectiveFromPage(activePage.imageDataUrl, box, 0.005);
    setPendingCropUrl(cropped);
  };

  const handleApplyCropToSelected = () => {
    if (!selectedDirective || !pendingBox || !pendingCropUrl) return;
    onUpdateDirectiveCrop(activePage.pageNumber, selectedDirective.id, pendingBox, pendingCropUrl);
    setPendingBox(null);
    setPendingCropUrl(null);
    setIsDrawMode(false);
  };

  const handleCreateNewFromCrop = () => {
    if (!pendingBox || !pendingCropUrl) return;
    const newItem: DirectiveItem = {
      id: `manual-p${activePage.pageNumber}-${Date.now().toString(36)}`,
      pageNumber: activePage.pageNumber,
      pdfSequence: 0,
      category: 'edit',
      priority: 'important',
      status: 'todo',
      titleVi: customTitle.trim() || `Vùng chỉ thị chụp thủ công (Trang ${activePage.pageNumber})`,
      actionRequiredVi:
        regionAiResult || 'Vùng hình ảnh được khoanh chụp thủ công từ bản vẽ PDF.',
      japaneseQuote: '',
      locationLabel: `Trang ${activePage.pageNumber} - Vùng chọn`,
      specs: [],
      box_2d: pendingBox,
      croppedImageUrl: pendingCropUrl,
      isManualCrop: true,
    };
    onAddManualDirective(activePage.pageNumber, newItem);
    setSelectedDirectiveId(newItem.id);
    setPendingBox(null);
    setPendingCropUrl(null);
    setCustomTitle('');
    setRegionAiResult(null);
    setIsDrawMode(false);
  };

  const handleTranslateCroppedRegion = async () => {
    if (!pendingCropUrl || isTranslatingRegion) return;
    setIsTranslatingRegion(true);
    setRegionAiResult(null);
    try {
      const res = await fetch('/api/ask-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl: pendingCropUrl,
          pageContext: `Trang ${activePage.pageNumber}: ${activePage.pageTitleVi}`,
          question:
            'Hãy đọc và dịch toàn bộ chữ tiếng Nhật, kích thước, mã vật liệu và giải thích rõ chỉ thị khách muốn làm hoặc chỉnh sửa trong vùng ảnh bản vẽ vừa chụp cắt này bằng tiếng Việt ngắn gọn, rõ ràng.',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Lỗi dịch vùng ảnh');
      setRegionAiResult(data.answer);
    } catch (err) {
      setRegionAiResult(err instanceof Error ? err.message : 'Không thể dịch vùng vừa chọn.');
    } finally {
      setIsTranslatingRegion(false);
    }
  };

  const liveDragBox: BoundingBox2D | null =
    dragStart && dragCurrent
      ? [
          Math.min(dragStart.y, dragCurrent.y),
          Math.min(dragStart.x, dragCurrent.x),
          Math.max(dragStart.y, dragCurrent.y),
          Math.max(dragStart.x, dragCurrent.x),
        ]
      : null;

  return (
    <div className="max-w-[1440px] mx-auto px-6 py-6">
      {/* Top Workspace Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-5 border-b border-slate-200">
        <div className="flex flex-wrap items-center gap-2">
          {project.pages.map((p) => (
            <button
              key={p.pageNumber}
              type="button"
              onClick={() => {
                setSelectedPageNum(p.pageNumber);
                setSelectedDirectiveId(p.directives[0]?.id ?? null);
                setPendingBox(null);
                setPendingCropUrl(null);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-medium tabular-nums transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activePage.pageNumber === p.pageNumber
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              Trang {p.pageNumber} ({p.directives.length})
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center border border-slate-200 rounded-lg bg-white overflow-hidden">
            <button
              type="button"
              onClick={() => setZoomPercent((z) => Math.max(60, z - 20))}
              className="p-2 text-slate-600 hover:bg-slate-50 cursor-pointer"
              aria-label="Thu nhỏ bản vẽ"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-2.5 text-xs font-mono tabular-nums text-slate-700">
              {zoomPercent}%
            </span>
            <button
              type="button"
              onClick={() => setZoomPercent((z) => Math.min(200, z + 20))}
              className="p-2 text-slate-600 hover:bg-slate-50 cursor-pointer"
              aria-label="Phóng to bản vẽ"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              setIsDrawMode((v) => !v);
              setPendingBox(null);
              setPendingCropUrl(null);
              setRegionAiResult(null);
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isDrawMode
                ? 'bg-blue-700 text-white'
                : 'border border-slate-300 bg-white text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Crop className="w-4 h-4" />
            {isDrawMode ? 'Đang bật chế độ khoanh vùng (Kéo chuột trên bản vẽ)' : 'Khoanh vùng chụp mới / Chụp lại'}
          </button>
        </div>
      </div>

      {/* Main Split: Drawing Canvas Left + Inspector Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Drawing Canvas */}
        <div className="lg:col-span-8 rounded-xl bg-slate-200/70 border border-slate-300 p-4 overflow-auto max-h-[78vh]">
          <div
            ref={imageContainerRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            style={{ width: `${zoomPercent}%` }}
            className={`relative mx-auto bg-white shadow-sm select-none ${
              isDrawMode ? 'cursor-crosshair' : 'cursor-default'
            }`}
          >
            <img
              src={activePage.imageDataUrl}
              alt={`Bản vẽ trang ${activePage.pageNumber}`}
              referrerPolicy="no-referrer"
              draggable={false}
              className="w-full h-auto block"
            />

            {/* Existing Directive Bounding Boxes */}
            {activePage.directives.map((d) => {
              const [ymin, xmin, ymax, xmax] = d.box_2d;
              const isSelected = d.id === selectedDirectiveId;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={(e) => {
                    if (isDrawMode) return;
                    e.stopPropagation();
                    setSelectedDirectiveId(d.id);
                  }}
                  style={{
                    top: `${ymin / 10}%`,
                    left: `${xmin / 10}%`,
                    height: `${(ymax - ymin) / 10}%`,
                    width: `${(xmax - xmin) / 10}%`,
                  }}
                  className={`absolute transition-colors text-left ${
                    isDrawMode ? 'pointer-events-none opacity-40' : 'cursor-pointer'
                  } ${
                    isSelected
                      ? 'border-2 border-blue-700 bg-blue-600/10 z-20'
                      : 'border border-red-500/75 bg-red-500/5 hover:bg-red-500/15 z-10'
                  }`}
                  title={d.titleVi}
                >
                  <span
                    className={`inline-block px-1.5 py-0.5 text-[11px] font-mono font-bold tabular-nums text-white ${
                      isSelected ? 'bg-blue-700' : 'bg-red-600'
                    }`}
                  >
                    #{formatDirectiveNumber(d)}
                  </span>
                </button>
              );
            })}

            {/* Live Dragging Rectangle */}
            {liveDragBox && (
              <div
                style={{
                  top: `${liveDragBox[0] / 10}%`,
                  left: `${liveDragBox[1] / 10}%`,
                  height: `${(liveDragBox[2] - liveDragBox[0]) / 10}%`,
                  width: `${(liveDragBox[3] - liveDragBox[1]) / 10}%`,
                }}
                className="absolute border-2 border-dashed border-blue-700 bg-blue-500/15 z-30 pointer-events-none"
              />
            )}

            {/* Pending Cropped Box */}
            {pendingBox && (
              <div
                style={{
                  top: `${pendingBox[0] / 10}%`,
                  left: `${pendingBox[1] / 10}%`,
                  height: `${(pendingBox[2] - pendingBox[0]) / 10}%`,
                  width: `${(pendingBox[3] - pendingBox[1]) / 10}%`,
                }}
                className="absolute border-2 border-emerald-600 bg-emerald-500/10 z-30 pointer-events-none"
              />
            )}
          </div>
        </div>

        {/* Right Inspector Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          {pendingCropUrl ? (
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
              <h2 className="text-sm font-semibold text-slate-900">
                Xem trước vùng vừa khoanh chụp
              </h2>
              <img
                src={pendingCropUrl}
                alt="Vùng chụp mới"
                referrerPolicy="no-referrer"
                className="w-full max-h-56 object-contain border border-slate-200 rounded bg-slate-50"
              />

              <button
                type="button"
                onClick={handleTranslateCroppedRegion}
                disabled={isTranslatingRegion}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg border border-blue-200 bg-blue-50 text-blue-800 text-xs font-medium hover:bg-blue-100 cursor-pointer disabled:opacity-60"
              >
                {isTranslatingRegion ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                Dịch & giải thích riêng vùng ảnh này bằng AI
              </button>

              {regionAiResult && (
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
                  {regionAiResult}
                </div>
              )}

              <div className="space-y-2 pt-2 border-t border-slate-200">
                {selectedDirective && (
                  <button
                    type="button"
                    onClick={handleApplyCropToSelected}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 cursor-pointer"
                  >
                    Cập nhật ảnh cho chỉ thị: &ldquo;{selectedDirective.titleVi}&rdquo;
                  </button>
                )}

                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="Tên chỉ thị mới (nếu muốn thêm mới)..."
                  className="w-full px-3 py-1.5 rounded-md border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-600"
                />

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleCreateNewFromCrop}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-blue-700 text-white text-xs font-medium hover:bg-blue-800 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Lưu thành chỉ thị mới
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      downloadDataUrl(pendingCropUrl, `Trang${activePage.pageNumber}_VungChup.png`)
                    }
                    className="inline-flex items-center justify-center gap-1 px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-700 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Tải
                  </button>
                </div>
              </div>
            </div>
          ) : selectedDirective ? (
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>
                  {CATEGORY_LABELS[selectedDirective.category]} ·{' '}
                  {PRIORITY_LABELS[selectedDirective.priority]}
                </span>
                <span className="font-mono tabular-nums">
                  Trang {selectedDirective.pageNumber}
                </span>
              </div>

              <h2 className="text-base font-semibold text-slate-900">
                {selectedDirective.titleVi}
              </h2>
              <p className="text-sm text-slate-700 leading-relaxed">
                {selectedDirective.actionRequiredVi}
              </p>

              {selectedDirective.japaneseQuote && (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700">
                  {selectedDirective.japaneseQuote}
                </div>
              )}

              {selectedDirective.croppedImageUrl && (
                <div className="space-y-2 pt-1">
                  <p className="text-xs font-medium text-slate-500">Ảnh chụp vùng chỉ thị:</p>
                  <img
                    src={selectedDirective.croppedImageUrl}
                    alt={selectedDirective.titleVi}
                    referrerPolicy="no-referrer"
                    className="w-full max-h-56 object-contain border border-slate-200 rounded bg-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsDrawMode(true)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-300 bg-white text-slate-800 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                    >
                      <Crop className="w-3.5 h-3.5" />
                      Khoanh chụp lại
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadDataUrl(
                          selectedDirective.croppedImageUrl!,
                          `Trang${selectedDirective.pageNumber}_${selectedDirective.id}.png`
                        )
                      }
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Tải ảnh
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-5 rounded-xl bg-white border border-slate-200 text-sm text-slate-600">
              Chọn một khung số trên bản vẽ hoặc bật chế độ &ldquo;Khoanh vùng chụp mới&rdquo; để cắt ảnh trực tiếp từ bản vẽ.
            </div>
          )}

          {/* Compact list of directives on this page */}
          <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-700">
                Chỉ thị trên trang {activePage.pageNumber}
              </h3>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {activePage.directives.length} mục
              </span>
            </div>
            <div className="divide-y divide-slate-200 max-h-64 overflow-y-auto">
              {activePage.directives.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => setSelectedDirectiveId(d.id)}
                  className={`w-full text-left px-4 py-2.5 text-xs transition-colors cursor-pointer ${
                    d.id === selectedDirectiveId ? 'bg-blue-50' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold tabular-nums text-slate-500">
                      #{formatDirectiveNumber(d)}
                    </span>
                    <span className="font-medium text-slate-900 truncate">{d.titleVi}</span>
                  </div>
                </button>
              ))}
              {activePage.directives.length === 0 && (
                <p className="p-4 text-xs text-slate-500">
                  Trang này không có chỉ thị redline. Bạn có thể kéo chuột ở chế độ khoanh vùng để chụp thủ công.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
