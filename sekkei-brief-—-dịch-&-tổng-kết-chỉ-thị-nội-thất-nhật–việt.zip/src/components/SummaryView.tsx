import React, { useMemo, useState } from 'react';
import {
  Download,
  Search,
  ArrowRight,
  Check,
  Crop,
  CheckCircle2,
} from 'lucide-react';
import {
  CATEGORY_LABELS,
  DirectivePriority,
  DirectiveStatus,
  DocumentProject,
  formatDirectiveNumber,
  PRIORITY_LABELS,
  STATUS_LABELS,
} from '../types';
import { exportProjectReportHtml } from '../utils/exportReport';

interface SummaryViewProps {
  project: DocumentProject;
  onGoToDirectives: (filterCategory?: string) => void;
  onJumpToPage: (pageNumber: number, directiveId?: string) => void;
  onUpdateStatus: (directiveId: string, status: DirectiveStatus) => void;
  onNotifyCompleted?: (label: string, onUndo?: () => void) => void;
}

const PRIORITY_STYLE: Record<
  DirectivePriority,
  { text: string; rowSurface: string; checkboxBorder: string }
> = {
  urgent: {
    text: 'text-red-700 font-bold',
    rowSurface: 'bg-red-50/45',
    checkboxBorder: 'border-red-600 hover:bg-red-50',
  },
  important: {
    text: 'text-amber-800 font-semibold',
    rowSurface: 'bg-white',
    checkboxBorder: 'border-blue-600 hover:bg-blue-50',
  },
  normal: {
    text: 'text-slate-600 font-medium',
    rowSurface: 'bg-white',
    checkboxBorder: 'border-slate-400 hover:border-blue-600 hover:bg-blue-50',
  },
};

export const SummaryView: React.FC<SummaryViewProps> = ({
  project,
  onGoToDirectives,
  onJumpToPage,
  onUpdateStatus,
  onNotifyCompleted,
}) => {
  const [translationQuery, setTranslationQuery] = useState('');
  const [checkedSummaryItems, setCheckedSummaryItems] = useState<Record<string, boolean>>({});

  const allDirectives = useMemo(
    () => project.pages.flatMap((p) => p.directives),
    [project.pages]
  );

  const doneCount = allDirectives.filter((d) => d.status === 'done').length;
  const pendingCount = allDirectives.length - doneCount;
  const progressPct =
    allDirectives.length > 0 ? Math.round((doneCount / allDirectives.length) * 100) : 0;

  const urgentCount = allDirectives.filter(
    (d) => d.priority === 'urgent' && d.status !== 'done'
  ).length;
  const editCount = allDirectives.filter((d) => d.category === 'edit').length;
  const createCount = allDirectives.filter((d) => d.category === 'create').length;
  const verifyCount = allDirectives.filter((d) => d.category === 'verify').length;

  const summary = project.executiveSummary;

  const orderedDirectives = useMemo(() => {
    const statusRank: Record<DirectiveStatus, number> = {
      todo: 0,
      in_progress: 1,
      done: 2,
    };
    return [...allDirectives].sort((a, b) => {
      const sDiff = statusRank[a.status] - statusRank[b.status];
      if (sDiff !== 0) return sDiff;
      return a.pdfSequence - b.pdfSequence;
    });
  }, [allDirectives]);

  const toggleSummaryCheck = (key: string, text: string) => {
    const nextVal = !checkedSummaryItems[key];
    setCheckedSummaryItems((prev) => ({ ...prev, [key]: nextVal }));
    if (nextVal) {
      onNotifyCompleted?.(text, () => {
        setCheckedSummaryItems((prev) => ({ ...prev, [key]: false }));
      });
    }
  };

  const filteredPages = project.pages.map((page) => {
    const q = translationQuery.trim().toLowerCase();
    const blocks = q
      ? page.translationBlocks.filter(
          (b) =>
            b.sectionLabel.toLowerCase().includes(q) ||
            b.japaneseOriginal.toLowerCase().includes(q) ||
            b.vietnameseTranslation.toLowerCase().includes(q)
        )
      : page.translationBlocks;
    return { ...page, filteredBlocks: blocks };
  });

  const renderSummaryChecklist = (groupKey: string, items: string[], accentClass: string) => {
    if (items.length === 0) {
      return <p className="text-sm text-slate-500">Không có mục nào.</p>;
    }
    return (
      <ul className="space-y-2.5">
        {items.map((item, i) => {
          const itemKey = `${groupKey}-${i}`;
          const isChecked = Boolean(checkedSummaryItems[itemKey]);
          return (
            <li key={itemKey}>
              <button
                type="button"
                onClick={() => toggleSummaryCheck(itemKey, item)}
                className={`w-full text-left flex items-start gap-3 p-2 -mx-2 rounded-lg transition-colors cursor-pointer ${
                  isChecked ? 'opacity-55 hover:opacity-80' : 'hover:bg-slate-50'
                }`}
              >
                <span
                  className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors ${
                    isChecked
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : `${accentClass} bg-white`
                  }`}
                >
                  {isChecked && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                </span>
                <span
                  className={`text-sm leading-relaxed ${
                    isChecked ? 'line-through text-slate-500' : 'text-slate-900 font-medium'
                  }`}
                >
                  {item}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    );
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 space-y-10">
      {/* Document Header */}
      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-5 pb-6 border-b border-slate-200">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="font-mono text-slate-700">{project.fileName}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{project.totalPages} trang</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums font-medium text-slate-700">
              Còn {pendingCount}/{allDirectives.length} chỉ thị chưa hoàn thành
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight text-balance">
            {summary?.projectTitleVi || project.fileName}
          </h1>
          {summary?.clientContextVi && (
            <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
              {summary.clientContextVi}
            </p>
          )}
        </div>

        <div className="flex items-center gap-3 shrink-0 no-print">
          <button
            type="button"
            onClick={() => onGoToDirectives('all')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-700 text-white text-sm font-medium hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Xem trang chỉ thị đầy đủ
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => exportProjectReportHtml(project)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-300 bg-white text-slate-700 text-sm font-medium hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Xuất báo cáo HTML
          </button>
        </div>
      </div>

      {/* Key Metrics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => onGoToDirectives('all')}
          className="text-left p-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 transition-colors cursor-pointer"
        >
          <p className="text-xs text-slate-500">Chưa hoàn thành</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-blue-700 mt-1">
            {pendingCount}
            <span className="text-sm font-normal text-slate-400"> / {allDirectives.length}</span>
          </p>
          <p className="text-xs text-red-700 font-medium mt-1 tabular-nums">
            {urgentCount > 0 ? `${urgentCount} việc cần sửa gấp` : 'Không có mục sửa gấp'}
          </p>
        </button>

        <button
          type="button"
          onClick={() => onGoToDirectives('edit')}
          className="text-left p-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 transition-colors cursor-pointer"
        >
          <p className="text-xs text-slate-500">Yêu cầu chỉnh sửa</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {editCount}
          </p>
          <p className="text-xs text-slate-500 mt-1">Góc nhìn, kích thước, vị trí</p>
        </button>

        <button
          type="button"
          onClick={() => onGoToDirectives('create')}
          className="text-left p-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 transition-colors cursor-pointer"
        >
          <p className="text-xs text-slate-500">Làm mới / Bổ sung</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {createCount}
          </p>
          <p className="text-xs text-slate-500 mt-1">Thêm chi tiết hoặc hạng mục</p>
        </button>

        <button
          type="button"
          onClick={() => onGoToDirectives('verify')}
          className="text-left p-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 transition-colors cursor-pointer"
        >
          <p className="text-xs text-slate-500">Cần hỏi lại khách Nhật</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-700 mt-1">
            {verifyCount}
          </p>
          <p className="text-xs text-slate-500 mt-1">Thông số cần xác nhận thêm</p>
        </button>
      </div>

      {/* Primary Focus: Interactive Tickable Directives */}
      <section aria-labelledby="action-board-heading" className="space-y-4">
        <div className="rounded-xl bg-white border border-slate-200 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h2 id="action-board-heading" className="text-xl font-bold text-slate-900">
                Những chỉ thị cần làm ngay
              </h2>
              {pendingCount === 0 && allDirectives.length > 0 && (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                  <CheckCircle2 className="w-4 h-4" />
                  Đã hoàn tất tất cả
                </span>
              )}
            </div>
            <p className="text-sm text-slate-600">
              Tick vào ô vuông bên trái khi thực hiện xong. Các mục chưa hoàn thành luôn được giữ nổi bật ở trên.
            </p>
          </div>

          <div className="sm:w-64 shrink-0 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-medium">
              <span className="text-slate-600">Tiến độ hoàn thành</span>
              <span className="font-mono tabular-nums text-slate-900">
                {doneCount}/{allDirectives.length} ({progressPct}%)
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
              <div
                className="h-full bg-emerald-600 transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        </div>

        {orderedDirectives.length > 0 ? (
          <div className="space-y-3">
            {orderedDirectives.map((item) => {
              const isDone = item.status === 'done';
              const pStyle = PRIORITY_STYLE[item.priority];

              return (
                <div
                  key={item.id}
                  className={`rounded-xl border p-5 transition-all ${
                    isDone
                      ? 'bg-slate-100/75 border-slate-200 opacity-60'
                      : item.priority === 'urgent'
                      ? `${pStyle.rowSurface} border-red-300 shadow-xs`
                      : 'bg-white border-blue-200 shadow-xs'
                  }`}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                    {/* Left: Prominent Tick Box + Action Details */}
                    <div className="lg:col-span-8 flex items-start gap-4">
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(item.id, isDone ? 'todo' : 'done')}
                        aria-label={
                          isDone
                            ? `Bỏ đánh dấu hoàn thành: ${item.titleVi}`
                            : `Đánh dấu đã hoàn thành: ${item.titleVi}`
                        }
                        title={isDone ? 'Nhấn để mở lại việc này' : 'Tick để báo đã hoàn thành'}
                        className={`mt-0.5 w-7 h-7 rounded-lg border-2 flex items-center justify-center shrink-0 transition-colors cursor-pointer no-print ${
                          isDone
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : `bg-white ${pStyle.checkboxBorder}`
                        }`}
                      >
                        {isDone && <Check className="w-4 h-4 stroke-[2.75]" />}
                      </button>

                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="font-mono font-bold text-slate-900 tabular-nums">
                            Chỉ thị {formatDirectiveNumber(item)}
                          </span>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          {isDone ? (
                            <span className="font-semibold text-emerald-700">
                              Đã hoàn thành
                            </span>
                          ) : (
                            <span className="font-bold text-blue-700">
                              Chưa hoàn thành
                            </span>
                          )}
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className={pStyle.text}>
                            {PRIORITY_LABELS[item.priority]}
                          </span>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className="font-medium text-slate-800">
                            {CATEGORY_LABELS[item.category]}
                          </span>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className="font-mono tabular-nums text-slate-600">
                            Trang {item.pageNumber}
                          </span>
                          <span aria-hidden="true" className="text-slate-300">·</span>
                          <span className="text-slate-600">{item.locationLabel}</span>
                        </div>

                        <h3
                          className={`text-base md:text-lg font-bold leading-snug ${
                            isDone ? 'text-slate-500 line-through' : 'text-slate-900'
                          }`}
                        >
                          {item.titleVi}
                        </h3>

                        <p
                          className={`text-sm leading-relaxed ${
                            isDone ? 'text-slate-500' : 'text-slate-900'
                          }`}
                        >
                          <span className="font-semibold">Cần làm: </span>
                          {item.actionRequiredVi}
                        </p>

                        {item.specs.length > 0 && (
                          <p className="text-xs font-mono tabular-nums text-blue-800">
                            Mã / Kích thước: {item.specs.join(' · ')}
                          </p>
                        )}

                        {item.japaneseQuote && (
                          <p className="text-xs text-slate-500 leading-relaxed">
                            <span className="font-medium text-slate-600">Ghi chú gốc: </span>
                            {item.japaneseQuote}
                          </p>
                        )}

                        <div className="pt-1 flex flex-wrap items-center gap-2 no-print">
                          <div className="inline-flex items-center bg-slate-100 p-0.5 rounded-md border border-slate-200">
                            {(['todo', 'in_progress', 'done'] as DirectiveStatus[]).map((st) => (
                              <button
                                key={st}
                                type="button"
                                onClick={() => onUpdateStatus(item.id, st)}
                                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1 ${
                                  item.status === st
                                    ? st === 'done'
                                      ? 'bg-emerald-700 text-white'
                                      : st === 'in_progress'
                                      ? 'bg-blue-700 text-white'
                                      : 'bg-white text-slate-900 shadow-sm'
                                    : 'text-slate-600 hover:text-slate-900'
                                }`}
                              >
                                {item.status === st && st === 'done' && <Check className="w-3 h-3" />}
                                {STATUS_LABELS[st]}
                              </button>
                            ))}
                          </div>

                          <button
                            type="button"
                            onClick={() => onJumpToPage(item.pageNumber, item.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Crop className="w-3.5 h-3.5" />
                            Xem trên bản vẽ
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Right: Cropped Visual Callout */}
                    <div className="lg:col-span-4">
                      {item.croppedImageUrl ? (
                        <button
                          type="button"
                          onClick={() => onJumpToPage(item.pageNumber, item.id)}
                          className="w-full rounded-lg border border-slate-200 bg-white p-2 hover:border-blue-400 transition-colors cursor-pointer block"
                          title="Nhấn để xem vị trí này trên bản vẽ gốc"
                        >
                          <img
                            src={item.croppedImageUrl}
                            alt={`Ảnh chỉ thị: ${item.titleVi}`}
                            referrerPolicy="no-referrer"
                            className="w-full max-h-44 object-contain mx-auto"
                          />
                        </button>
                      ) : (
                        <div className="h-32 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center text-xs text-slate-400">
                          Không có ảnh cắt vùng
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 rounded-xl bg-white border border-slate-200 text-sm text-slate-500 text-center">
            Chưa phát hiện chỉ thị chỉnh sửa nào trong tài liệu này.
          </div>
        )}
      </section>

      {/* Executive Summary Overview Grid (also tickable!) */}
      {summary && (
        <section aria-labelledby="exec-summary-heading" className="space-y-4">
          <div>
            <h2 id="exec-summary-heading" className="text-lg font-semibold text-slate-900">
              Tổng kết chung toàn bộ hồ sơ
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Bạn có thể tick đánh dấu từng đầu mục tóm tắt sau khi hoàn thành
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
              <div className="px-5 py-3 bg-red-50/60 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-red-800">
                  01. Ưu tiên xử lý ngay
                </h3>
              </div>
              <div className="p-5">
                {renderSummaryChecklist('prio', summary.topPrioritiesVi, 'border-red-400')}
              </div>
            </div>

            <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
              <div className="px-5 py-3 bg-slate-50 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">
                  02. Chi tiết cần chỉnh sửa trên bản vẽ / 3D
                </h3>
              </div>
              <div className="p-5">
                {renderSummaryChecklist('rev', summary.revisionsSummaryVi, 'border-slate-400')}
              </div>
            </div>

            <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
              <div className="px-5 py-3 bg-blue-50/60 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-blue-900">
                  03. Hạng mục làm mới / bổ sung
                </h3>
              </div>
              <div className="p-5">
                {renderSummaryChecklist('new', summary.newWorkSummaryVi, 'border-blue-500')}
              </div>
            </div>

            <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
              <div className="px-5 py-3 bg-amber-50/60 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-amber-900">
                  04. Điểm cần hỏi lại khách Nhật
                </h3>
              </div>
              <div className="p-5">
                {renderSummaryChecklist('clar', summary.clarificationsNeededVi, 'border-amber-500')}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Full Bilingual Translation by Page */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Bản dịch chi tiết Nhật – Việt theo từng trang
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Đối chiếu nguyên văn tiếng Nhật trên bản vẽ với bản dịch tiếng Việt chuyên ngành
            </p>
          </div>
          <div className="relative w-full sm:w-72 no-print">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={translationQuery}
              onChange={(e) => setTranslationQuery(e.target.value)}
              placeholder="Tìm trong bản dịch..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        <div className="space-y-6">
          {filteredPages.map((page) => (
            <div
              key={page.pageNumber}
              className="rounded-xl bg-white border border-slate-200 overflow-hidden"
            >
              <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-semibold text-slate-700 tabular-nums">
                      Trang {page.pageNumber}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{page.documentTypeVi}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{page.directives.length} chỉ thị</span>
                  </div>
                  <h3 className="text-base font-semibold text-slate-900 mt-0.5">
                    {page.pageTitleVi}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => onJumpToPage(page.pageNumber)}
                  className="text-xs font-medium text-blue-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer no-print"
                >
                  Mở bản vẽ trang {page.pageNumber}
                </button>
              </div>

              <div className="p-5 space-y-4">
                <p className="text-sm text-slate-700 leading-relaxed">{page.pageSummaryVi}</p>

                {page.filteredBlocks.length > 0 ? (
                  <div className="overflow-x-auto border border-slate-200 rounded-lg">
                    <table className="w-full text-left border-collapse text-sm">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500">
                          <th className="py-2.5 px-3 font-medium w-44">Khu vực / Mục</th>
                          <th className="py-2.5 px-3 font-medium w-2/5">Nguyên văn tiếng Nhật</th>
                          <th className="py-2.5 px-3 font-medium">Bản dịch tiếng Việt & Ghi chú</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {page.filteredBlocks.map((block) => (
                          <tr key={block.id} className="align-top hover:bg-slate-50/70">
                            <td className="py-3 px-3 font-medium text-slate-800">
                              {block.sectionLabel}
                            </td>
                            <td className="py-3 px-3 text-slate-600 whitespace-pre-line">
                              {block.japaneseOriginal}
                            </td>
                            <td className="py-3 px-3 text-slate-900">
                              <p className="whitespace-pre-line">{block.vietnameseTranslation}</p>
                              {block.contextNote && (
                                <p className="text-xs text-slate-500 mt-1">
                                  Ghi chú: {block.contextNote}
                                </p>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">
                    Không có đoạn dịch nào khớp từ khóa tìm kiếm trên trang này.
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
