import React, { useMemo, useState } from 'react';
import {
  Search,
  Download,
  Crop,
  Maximize2,
  X,
  Check,
  CheckCircle2,
} from 'lucide-react';
import {
  CATEGORY_LABELS,
  DirectiveCategory,
  DirectiveItem,
  DirectivePriority,
  DirectiveStatus,
  DocumentProject,
  formatDirectiveNumber,
  PRIORITY_LABELS,
  STATUS_LABELS,
} from '../types';
import { downloadDataUrl, exportProjectReportHtml } from '../utils/exportReport';

interface DirectivesViewProps {
  project: DocumentProject;
  initialCategoryFilter?: string;
  onUpdateStatus: (directiveId: string, status: DirectiveStatus) => void;
  onInspectDirective: (pageNumber: number, directiveId: string) => void;
}

const PRIORITY_TEXT_CLASS: Record<DirectivePriority, string> = {
  urgent: 'text-red-700 font-bold',
  important: 'text-amber-800 font-semibold',
  normal: 'text-slate-600 font-medium',
};

const CATEGORY_TEXT_CLASS: Record<DirectiveCategory, string> = {
  edit: 'text-blue-700 font-semibold',
  create: 'text-emerald-700 font-semibold',
  material: 'text-slate-800 font-semibold',
  dimension: 'text-slate-800 font-semibold',
  verify: 'text-amber-700 font-semibold',
};

export const DirectivesView: React.FC<DirectivesViewProps> = ({
  project,
  initialCategoryFilter = 'all',
  onUpdateStatus,
  onInspectDirective,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>(initialCategoryFilter);
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [pageFilter, setPageFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [lightboxItem, setLightboxItem] = useState<DirectiveItem | null>(null);

  const allDirectives = useMemo(
    () => project.pages.flatMap((p) => p.directives),
    [project.pages]
  );

  const doneCount = allDirectives.filter((d) => d.status === 'done').length;
  const pendingCount = allDirectives.length - doneCount;
  const progressPct =
    allDirectives.length > 0 ? Math.round((doneCount / allDirectives.length) * 100) : 0;

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const statusRank: Record<DirectiveStatus, number> = {
      todo: 0,
      in_progress: 1,
      done: 2,
    };

    return allDirectives
      .filter((d) => {
        if (categoryFilter !== 'all' && d.category !== categoryFilter) return false;
        if (priorityFilter !== 'all' && d.priority !== priorityFilter) return false;
        if (statusFilter === 'pending' && d.status === 'done') return false;
        if (statusFilter === 'done' && d.status !== 'done') return false;
        if (pageFilter !== 'all' && String(d.pageNumber) !== pageFilter) return false;
        if (!q) return true;
        return (
          d.titleVi.toLowerCase().includes(q) ||
          d.actionRequiredVi.toLowerCase().includes(q) ||
          d.japaneseQuote.toLowerCase().includes(q) ||
          d.locationLabel.toLowerCase().includes(q) ||
          d.specs.some((s) => s.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => {
        const sDiff = statusRank[a.status] - statusRank[b.status];
        if (sDiff !== 0) return sDiff;
        return a.pdfSequence - b.pdfSequence;
      });
  }, [allDirectives, categoryFilter, priorityFilter, statusFilter, pageFilter, searchQuery]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: allDirectives.length };
    for (const d of allDirectives) {
      counts[d.category] = (counts[d.category] || 0) + 1;
    }
    return counts;
  }, [allDirectives]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-5 border-b border-slate-200">
        <div className="space-y-1">
          <p className="text-xs text-slate-500 tabular-nums">
            {project.fileName} · Còn {pendingCount}/{allDirectives.length} chỉ thị chưa hoàn thành
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Danh sách chỉ thị cần làm & hình ảnh vùng chỉ thị
            </h1>
            {pendingCount === 0 && allDirectives.length > 0 && (
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                <CheckCircle2 className="w-4 h-4" />
                Đã hoàn tất toàn bộ
              </span>
            )}
          </div>
        </div>
        <button
          type="button"
          onClick={() => exportProjectReportHtml(project)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm font-medium hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          Xuất báo cáo kèm ảnh
        </button>
      </div>

      {/* Progress Banner */}
      <div className="rounded-xl bg-white border border-slate-200 px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <span className="text-xs text-slate-600">
          Tick vào ô vuông bên trái mỗi chỉ thị khi làm xong. Mục chưa hoàn thành sẽ được giữ nổi bật ở trên.
        </span>
        <div className="sm:w-64 shrink-0 space-y-1">
          <div className="flex items-center justify-between text-xs font-medium">
            <span className="text-slate-600">Đã xong</span>
            <span className="font-mono tabular-nums text-slate-900">
              {doneCount}/{allDirectives.length} ({progressPct}%)
            </span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
            <div
              className="h-full bg-emerald-600 transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit max-w-full overflow-x-auto">
          {(
            [
              ['all', 'Tất cả'],
              ['edit', 'Chỉnh sửa'],
              ['create', 'Làm mới / Bổ sung'],
              ['material', 'Vật liệu / Mã màu'],
              ['dimension', 'Kích thước / Kỹ thuật'],
              ['verify', 'Cần xác nhận'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setCategoryFilter(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                categoryFilter === key
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}{' '}
              <span className="font-mono tabular-nums text-slate-400 ml-1">
                {categoryCounts[key] || 0}
              </span>
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm theo từ khóa tiếng Việt, tiếng Nhật, mã vật liệu..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <select
            aria-label="Lọc theo trạng thái xử lý"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">Mọi trạng thái</option>
            <option value="pending">Chưa hoàn thành ({pendingCount})</option>
            <option value="done">Đã hoàn thành ({doneCount})</option>
          </select>

          <select
            aria-label="Lọc theo mức độ ưu tiên"
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">Mọi mức độ ưu tiên</option>
            <option value="urgent">Khẩn cấp</option>
            <option value="important">Quan trọng</option>
            <option value="normal">Thông thường</option>
          </select>

          <select
            aria-label="Lọc theo trang PDF"
            value={pageFilter}
            onChange={(e) => setPageFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">Tất cả các trang ({project.totalPages})</option>
            {project.pages.map((p) => (
              <option key={p.pageNumber} value={String(p.pageNumber)}>
                Trang {p.pageNumber} ({p.directives.length} chỉ thị)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Directive List */}
      {filtered.length === 0 ? (
        <div className="p-12 rounded-xl bg-white border border-slate-200 text-center">
          <p className="text-sm font-medium text-slate-800">
            Không tìm thấy chỉ thị nào khớp bộ lọc hiện tại.
          </p>
          <button
            type="button"
            onClick={() => {
              setCategoryFilter('all');
              setPriorityFilter('all');
              setStatusFilter('all');
              setPageFilter('all');
              setSearchQuery('');
            }}
            className="mt-3 text-xs font-medium text-blue-700 hover:underline cursor-pointer"
          >
            Xóa bộ lọc để xem toàn bộ
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((item) => {
            const isDone = item.status === 'done';
            return (
              <article
                key={item.id}
                className={`rounded-xl border p-5 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start transition-all ${
                  isDone
                    ? 'bg-slate-100/75 border-slate-200 opacity-60'
                    : item.priority === 'urgent'
                    ? 'bg-red-50/35 border-red-300 shadow-xs'
                    : 'bg-white border-blue-200 shadow-xs'
                }`}
              >
                {/* Left: Checkbox + Vietnamese Instruction & Japanese Source */}
                <div className="lg:col-span-7 flex items-start gap-4">
                  <button
                    type="button"
                    onClick={() => onUpdateStatus(item.id, isDone ? 'todo' : 'done')}
                    aria-label={
                      isDone
                        ? `Bỏ đánh dấu hoàn thành: ${item.titleVi}`
                        : `Đánh dấu đã hoàn thành: ${item.titleVi}`
                    }
                    title={isDone ? 'Nhấn để mở lại việc này' : 'Tick để báo đã hoàn thành'}
                    className={`mt-0.5 w-7 h-7 rounded-lg border-2 flex items-center justify-center shrink-0 transition-colors cursor-pointer no-print ${
                      isDone
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : item.priority === 'urgent'
                        ? 'bg-white border-red-600 hover:bg-red-50'
                        : 'bg-white border-blue-600 hover:bg-blue-50'
                    }`}
                  >
                    {isDone && <Check className="w-4 h-4 stroke-[2.75]" />}
                  </button>

                  <div className="flex-1 min-w-0 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono font-bold text-slate-800 tabular-nums">
                          Chỉ thị {formatDirectiveNumber(item)}
                        </span>
                        <span aria-hidden="true">·</span>
                        {isDone ? (
                          <span className="font-semibold text-emerald-700">Đã hoàn thành</span>
                        ) : (
                          <span className="font-bold text-blue-700">Chưa hoàn thành</span>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-slate-700">
                          Trang {item.pageNumber}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className={CATEGORY_TEXT_CLASS[item.category]}>
                          {CATEGORY_LABELS[item.category]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className={PRIORITY_TEXT_CLASS[item.priority]}>
                          {PRIORITY_LABELS[item.priority]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-700">{item.locationLabel}</span>
                      </div>
                    </div>

                    <h2
                      className={`text-lg font-bold leading-snug ${
                        isDone ? 'text-slate-500 line-through' : 'text-slate-900'
                      }`}
                    >
                      {item.titleVi}
                    </h2>

                    <div
                      className={`p-3.5 rounded-lg border space-y-2 ${
                        isDone
                          ? 'bg-slate-100 border-slate-200'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <p className="text-xs font-semibold uppercase tracking-wider text-blue-800">
                        Nội dung cần thực hiện
                      </p>
                      <p
                        className={`text-sm leading-relaxed font-medium ${
                          isDone ? 'text-slate-500' : 'text-slate-900'
                        }`}
                      >
                        {item.actionRequiredVi}
                      </p>
                      {item.specs.length > 0 && (
                        <p className="text-xs font-mono tabular-nums text-blue-800 pt-1">
                          Thông số / Mã: {item.specs.join(' · ')}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="inline-flex items-center gap-1 bg-slate-100 p-0.5 rounded-md border border-slate-200">
                        {(['todo', 'in_progress', 'done'] as DirectiveStatus[]).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => onUpdateStatus(item.id, st)}
                            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1 ${
                              item.status === st
                                ? st === 'done'
                                  ? 'bg-emerald-700 text-white'
                                  : st === 'in_progress'
                                  ? 'bg-blue-700 text-white'
                                  : 'bg-white text-slate-900 shadow-sm'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {item.status === st && st === 'done' && <Check className="w-3 h-3" />}
                            {STATUS_LABELS[st]}
                          </button>
                        ))}
                      </div>
                    </div>

                    {item.japaneseQuote && (
                      <div className="text-xs text-slate-500 leading-relaxed">
                        <span className="font-semibold text-slate-600">Nguyên văn tiếng Nhật: </span>
                        <span>{item.japaneseQuote}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Automatically Cropped Image of Directive */}
                <div className="lg:col-span-5 flex flex-col gap-2.5">
                  <div className="relative rounded-lg border border-slate-200 bg-slate-50 overflow-hidden group">
                    {item.croppedImageUrl ? (
                      <button
                        type="button"
                        onClick={() => setLightboxItem(item)}
                        className="block w-full text-left cursor-zoom-in"
                        title="Nhấn để phóng to ảnh vùng chỉ thị"
                      >
                        <img
                          src={item.croppedImageUrl}
                          alt={`Ảnh chụp vùng chỉ thị: ${item.titleVi}`}
                          referrerPolicy="no-referrer"
                          className="w-full max-h-64 object-contain bg-white mx-auto"
                        />
                        <span className="absolute top-2 right-2 p-1.5 rounded-md bg-slate-900/75 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                          <Maximize2 className="w-3.5 h-3.5" />
                        </span>
                      </button>
                    ) : (
                      <div className="h-40 flex items-center justify-center text-xs text-slate-500">
                        Chưa có ảnh cắt vùng chỉ thị
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => onInspectDirective(item.pageNumber, item.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Crop className="w-3.5 h-3.5" />
                      Xem trên bản vẽ / Chụp lại
                    </button>

                    {item.croppedImageUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          downloadDataUrl(
                            item.croppedImageUrl!,
                            `Trang${item.pageNumber}_ChiThi_${item.pdfSequence}.png`
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Tải ảnh chụp
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Lightbox Modal for Cropped Image */}
      {lightboxItem && lightboxItem.croppedImageUrl && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
          onClick={() => setLightboxItem(null)}
        >
          <div
            className="max-w-4xl w-full bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <p className="text-xs text-slate-500 tabular-nums">
                  Trang {lightboxItem.pageNumber} · {lightboxItem.locationLabel}
                </p>
                <h3 className="text-sm font-semibold text-slate-900 truncate">
                  {lightboxItem.titleVi}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setLightboxItem(null)}
                className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                aria-label="Đóng cửa sổ phóng to"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 bg-slate-100 max-h-[70vh] overflow-auto flex justify-center">
              <img
                src={lightboxItem.croppedImageUrl}
                alt={lightboxItem.titleVi}
                referrerPolicy="no-referrer"
                className="max-w-full h-auto bg-white border border-slate-200 rounded"
              />
            </div>
            <div className="px-5 py-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
              <p className="text-slate-700 max-w-2xl">{lightboxItem.actionRequiredVi}</p>
              <button
                type="button"
                onClick={() =>
                  downloadDataUrl(
                    lightboxItem.croppedImageUrl!,
                    `Trang${lightboxItem.pageNumber}_${lightboxItem.id}.png`
                  )
                }
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 text-white font-medium hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Tải ảnh PNG
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
